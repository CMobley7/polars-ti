# -*- coding: utf-8 -*-
# =============================================================================
# Polars CDL_2CROWS Implementation
# =============================================================================
"""Candle Pattern: Two Crows."""

from typing import Any

import numpy as np

from polars_ti._typing import IntoExpr, PlExpr
from polars_ti.candles._cdl_math import (
    AVG_FACTOR,
    CandleArrays,
    CandleSetting,
    candle_avg_period,
    run_pattern,
)


def _detect(ca: CandleArrays, out: np.ndarray, **kwargs: Any) -> None:
    # Lookback: TA_CANDLEAVGPERIOD(BodyLong) + 2
    body_long_period = candle_avg_period(CandleSetting.BodyLong)
    lookback = body_long_period + 2
    start_idx = lookback
    if start_idx >= len(out):
        return

    arr_bl = ca._ranges[CandleSetting.BodyLong]
    body_hi = ca.body_high
    body_lo = ca.body_low

    body_long_trail = start_idx - 2 - body_long_period
    body_long_total = float(arr_bl[body_long_trail : start_idx - 2].sum())
    for i in range(start_idx, len(out)):
        if (
            ca.color[i - 2] == 1  # 1st: white
            and ca.real_body[i - 2] > AVG_FACTOR[CandleSetting.BodyLong] * body_long_total  # long
            and ca.color[i - 1] == -1  # 2nd: black
            and body_lo[i - 1] > body_hi[i - 2]  # gapping up
            and ca.color[i] == -1  # 3rd: black
            and ca.open[i] < ca.open[i - 1]
            and ca.open[i] > ca.close[i - 1]  # opening within 2nd rb
            and ca.close[i] > ca.open[i - 2]
            and ca.close[i] < ca.close[i - 2]  # closing within 1st rb
        ):
            out[i] = -100

        body_long_total += arr_bl[i - 2] - arr_bl[body_long_trail]
        body_long_trail += 1


def cdl_2crows(
    open_: IntoExpr,
    high: IntoExpr,
    low: IntoExpr,
    close: IntoExpr,
    scalar: float = 100.0,
    offset: int = 0,
    talib: bool = True,
) -> PlExpr:
    """Polars: Candle Pattern - Two Crows.

    Args:
        open_: Column name or pl.Expr for 'open' prices.
        high: Column name or pl.Expr for 'high' prices.
        low: Column name or pl.Expr for 'low' prices.
        close: Column name or pl.Expr for 'close' prices.
        scalar: Result multiplier. Default: 100.0
        offset: Shift result by N periods. Default: 0
        talib: Use TA-Lib when installed. Default: True

    Returns:
        pl.Expr: CDL_2CROWS expression (-scalar / 0).
    """
    return run_pattern(
        open_,
        high,
        low,
        close,
        _detect,
        "CDL_2CROWS",
        "2CROWS",
        scalar=scalar,
        offset=offset,
        talib=talib,
    )
